<?php

namespace CCNode\Accounts;
use CCNode\Accounts\User;

/**
 * Class representing a member of the ledger
 */
class Admin extends User {


}

