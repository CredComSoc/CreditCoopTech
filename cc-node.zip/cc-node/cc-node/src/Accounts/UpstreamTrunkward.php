<?php
namespace CCNode\Accounts;

final class UpstreamTrunkward extends Trunkward {

}


