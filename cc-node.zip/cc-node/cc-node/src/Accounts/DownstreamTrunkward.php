<?php
namespace CCNode\Accounts;

final class DownstreamTrunkward extends Trunkward {

}


