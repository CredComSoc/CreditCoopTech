<?php

namespace CCNode\Accounts;

/**
 * Class representing an account
 */
final class UpstreamBranch extends Branch {

}


